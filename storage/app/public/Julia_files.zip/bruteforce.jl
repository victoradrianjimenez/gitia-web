# module imports, used in nonlinear function
using Distributions

# pre-loading of called functions 
reload("nonlinearfunction.jl")

# input variables
file = "A310.txt"		# data file to be read
mincap = 0.3            # minimum capacity for nonlinear function
maxcap = 1.0            # maximum capacity for nonlinear function
mu = 0.85               # sigma for nonlinear function
std = 0.25              # standard deviation for nonlinear function

# Load data from input file.
# File format is specified in in OR-Library: http://people.brunel.ac.uk/~mastjjb/jeb/orlib/gapinfo.html

# Open the file
fileID = open(file)
# The specified file should be in the same directory than this script. Otherwise an error will occur.

# read the first line, and obtain the parameters m and n
firstLine = readline(fileID)
firstLine = split(firstLine)
m = int(firstLine[1]) 		# obtain the number of rows (agents)
n = int(firstLine[2])		# obtain the number of columns (jobs)

# Obtain the matrices a and c
c = zeros(n,m)
a = zeros(n,m)
for i=1:m
	linea = readline(fileID)
	linea = split(linea)
	c[:,i] = int(linea)
end
for i=1:m
	linea = readline(fileID)
	linea = split(linea)
	a[:,i] = int(linea)
end
a = a'
c = c'

# Obtain the vector b
linea = readline(fileID)
linea = split(linea)
b = int(linea)

###### End of data loading

# Variables initialization
assignments = zeros(m^n,n)		# Each row of this matrix is a possible assignment
profits = zeros(m^n,m)			# Each row contains the profit of each agent for an assignment
capacityUsed = zeros(m^n,m)		# Each row shows the agents' capacity used for an assignment
solutionsCount = 0				# Counter of valid solutions
validSolutions = zeros(m^n,2)	# Each row contains the Z value for a valid solution and the assignment number that generated it

###### Main loop
tic()
for i=1:m^n						# The loop generates all possible assignments
	# First it generates one assignment
	aux = base(m, i-1, n)
	for j=1:n
		assignments[i,j] = int(aux[j]) - 48 + 1 
	end

	# Then, for each agent...
	for k=1:m
		# ... find wich jobs have been assigned to it,
		indexes = find(assignments[i,:] .== k)
		# calculate the capacity used, 
		capacityUsed[i,k] = sum(a[k,indexes]) / b[k]
		# and calculates its profit.
		profits[i,k] = sum(1 ./ c[k,indexes])
	end

	# Calculate the efficiency factor for every agent
	hj = nonlinearfunction(mincap, maxcap, mu, std, capacityUsed[i,:])

	if (all(hj .> 0))  # If the assignment is a valid solution...
		# increment the counter,
		solutionsCount = solutionsCount + 1
		# calculate the Z value, and store it into an array.
		validSolutions[solutionsCount,1] = sum(hj .* profits[i,:])
		validSolutions[solutionsCount,2] = i
	end
end
toc()
# End of Main loop

if (solutionsCount > 0)
	println(solutionsCount)
	optimumValue = maximum(validSolutions[:,1])
	ind = find(validSolutions[:,1] .== optimumValue)
	println(optimumValue)
	iSol = validSolutions[ind,2]
	println(capacityUsed[iSol,:])
	println(assignments[iSol,:])
else
	print_with_color(:red, "Sin soluciones")
end

# Free memory
assignments= 0
validSolutions = 0
capacityUsed = 0
solutionsCount = 0
profits = 0
m = 0
n = 0
a = 0
b=0
c=0
gc()
