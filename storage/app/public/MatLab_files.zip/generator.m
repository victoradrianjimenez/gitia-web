clc;
clear;

%%%%% input variables
m = 3;  % number of rows (agents)
n = 10; % number of columns (jobs)
type = 'A'; % type of benchmark to create ['A', 'B', 'C', 'D']


% generate matrices A, B and C depending on selected type
switch type
    case 'A' 
		c = round(rand(m,n)*40 + 10);
		a = round(rand(m,n)*20 + 5)
		[v,iMin] = min (c);
		for k = 1:m
			R(k) = sum(a(k,:) .* [iMin == k]);
		end
		RM = max(R)
		b = round(ones(m,1) * (0.6 * n/m * 15 + 0.4 * RM));
    case 'B'
		c = round(rand(m,n)*40 + 10);
		a = round(rand(m,n)*20 + 5);
		[v,iMin] = min (c);
		for k=1:m
			R(k) = sum(a(k,:).*[iMin==k]);
		end
		RM = max(R);
		b = round(0.7*ones(m,1)*(0.6*n/m*15 + 0.4*RM));
    case 'C'
		c = round(rand(m,n)*40 +10);
		a = round(rand(m,n)*20 +5);
		b = round(0.8*(sum(a')./m));
    case 'D'
		a = round(rand(m,n)*99 +1);
		e = round (rand(m,n)*20 -10);
		c = 111 - a + e;
		b = round(0.8*(sum(a')./m));
    otherwise
		c = ones(m,n);
		a = ones(m,n);
		b = ones(m,1);
end


%%%%% write result to a text file
%%%%% file format is specified in in OR-Library: http://people.brunel.ac.uk/~mastjjb/jeb/orlib/gapinfo.html

% file name will contain benchmark type, and row and column size, ie: 'A310.txt'
filename = strcat(type, int2str(m), int2str(n),'.txt');

% Open the file. If the file does not exists, it will be created; if it does, it will be overwritten.
fileID = fopen(filename,'w');

% write the first line
fprintf(fileID,'%d %d\n', m, n);

% write the C matrix
for i=1:m  
  fprintf(fileID,'%d ', c(i,:));
  fprintf(fileID,'\n');
end

% write the A matrix
for i=1:m  
  fprintf(fileID,'%d ', a(i,:));
  fprintf(fileID,'\n');
end

% write the B vector
fprintf(fileID,'%d ', b);

% close the file
fclose(fileID);

%%%%% end