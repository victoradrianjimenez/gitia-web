clear;

%%%%% input variables
file = 'A310.txt';  % data file to be read
mincap = 0.3;       % minimum capacity for nonlinear function
maxcap = 1;         % maximum capacity for nonlinear function
mu = 0.85;          % sigma for nonlinear function
sd = 0.25;          % standard deviation for nonlinear function


%%%%%% Load data from input file.
% File format is specified in in OR-Library: http://people.brunel.ac.uk/~mastjjb/jeb/orlib/gapinfo.html

% Open the file
fileID = fopen(file);
% The specified file should be in the same directory than this script. Otherwise an error will occur.

% read the first line, and obtain the parameters m and n
firstLine = textscan(fileID,'%d',2,'CollectOutput',1);
firstLine = cell2mat(firstLine);
m = firstLine(1); % obtain the number of rows (agents)
n = firstLine(2); % obtain the number of columns (jobs)

% read the rest of the lines, and obtain the matrices a, b and c
auxMatrix = textscan(fileID,'%d');
auxMatrix = cell2mat(auxMatrix);
c = double(reshape(auxMatrix(1:m*n),n,[])'); 
a = double(reshape(auxMatrix(m*n+1:2*m*n),n,[])');
b = double(reshape(auxMatrix(2*m*n+1:end),m,1));

% close the file
fclose(fileID);
%%%%%% End of data loading

%%%%%% Initialization of variables
assignments = zeros(m^n,n);     % Each row of this matrix is a possible assignment
capacityUsed = zeros(m^n,m);    % Each row shows the agents' capacity used for an assignment
solutionsCount=0;               % Counter of valid solutions

%%%%%% Main loop
tic
for i=1:m^n     % The loop generates all possible assignments
    % First it generates one assignment
    assignments(i,:) = str2num(dec2base(i-1, m, n)')';
    assignments(i,:) = assignments(i,:) + ones(1,n);
    
    % Then, for each agent...
    for k=1:m    
        % ... find wich jobs have been assigned to it,
        indK = [(assignments(i,:) == k)];
        % calculate the capacity used, 
        capacityUsed(i,k) = sum(indK .* a(k,:)) / b(k);
        % and calculates its profit.
        profits(k) = sum(indK .* (1 ./ c(k,:)));
    end
    
    % Calculate the efficiency factor for every agent
    h = nonlinearfunction(mincap, maxcap, mu, sd, capacityUsed(i,:));
    
    if (h > 0)  % If the assignment is a valid solution...
        % increment the counter,
        solutionsCount = solutionsCount + 1;
        % calculate the Z value, and store it into an array.
        validSolutions(solutionsCount,1) = sum(h .* profits);
        validSolutions(solutionsCount,2) = i;
    end
        
end
toc
%%%%%% End of Main loop

solutionsCount
[optimumValue,ind] = max(validSolutions(:,1));
optimumValue
capacityUsed(validSolutions(ind,2),:)
