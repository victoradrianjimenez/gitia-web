%%%%% This function models a non linear function in the interval [0,...].
%%%%% Below a minimum value, and over a maximum value, it returns zero.
%%%%% Between min-max values, it returns a normalized gaussian, whose sigma
%%%%% and standard deviation are inputs.

function hj = nonlinearfunction(minval, maxval, sigma, std, vector)
    hj = zeros(1,size(vector,2));
    if (vector >= minval)
        if (vector <= maxval)
            hj = pdf('normal', vector, sigma, std) ./ pdf('normal', sigma, sigma, std);
        end
    end